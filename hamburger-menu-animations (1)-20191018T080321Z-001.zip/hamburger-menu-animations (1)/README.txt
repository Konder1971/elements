A Pen created at CodePen.io. You can find this one at https://codepen.io/Zaku/pen/ejLNJL.

 Four different menu animations for menu button toggle between hamburger, cross and back icon.

Prefer Dots?
Go this way: https://codepen.io/Zaku/details/YjRqzB/

Additional Source: https://github.com/tamino-martinius/ui-snippets-menu-animations