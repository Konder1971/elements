<?php

//lazy ;)

 header("Location: demo.html");
 
